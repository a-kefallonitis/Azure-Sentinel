import json
from unittest import TestCase
from unittest.mock import ANY, patch, MagicMock
import os
import importlib
from shared_code import configurations

from requests.models import HTTPError

MOCK_TOKEN = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJjaWQiOiI4Yzg0MDg3My0zMTQ1LTRlNWEtYWVkZS0wMjE2NzljZTIzZDgiLCJjcGlkIjoic3ZwIiwicHBpZCI6ImN1cyIsIml0IjoxNjE1ODgwNzg1LCJ1aWQiOiJteGRyXzRiOTE0ZTYyQG1kci50cmVuZG1pY3JvLmNvbSIsInBsIjoiIiwiZXQiOjE2NDc0MTY3ODV9.V2SZHU85H8K55DpzHemToIr55kWaOQMWVV5CdImKGSePpntapsqW1tIEKbpuAemMyicKUNM1ewwC8fwJNZl7bW8puugYg92ynkXWGqKQiureKwCZM7Kfp-L-4LUvTsLF_DVDCECsptJNKkFZANryKqOFdEmiowmwRaqkoHkDT5qF_xCRnGx5nfzof8Nb_ey6PMQuH2mdOJRtfHkW4m9HZ3C-Ab2kuizD3J-BkOWGmn642hv1C9ClNp5IesMF_bhT21rIO4jkSW6GPz5nb9cEFMuepJK7F8177BGNh8LfJzfmeGgX141QGje4LdSXGq0eUlXzFxg0hMAXCS35a6bQeKGTh5Dfnxt4iSGLq47_ddiSEBifWuMiLyjAbxxV9QiF-Bee9q_gZdsczJCO9c7I4eoW2acqTOva-Ts0VVenXrp0g5qdBtZgoFOG4BZj_dnzla3fUa60rFlsE6_4VbSv0-mV7yZirRrB7cxwb2Gqzw_7dFCdKEg3Eax5ljT882FtJeUFGH1cOyUf-Uj4YlfByDSQyvPtqlyNoHX66Jz6yauWuJbL9n1cN_ZseKdf3gQtRRenNTLZG84dATj-WKYcp3w-KJtpCEDxLFbZFwb5Te7NlxrItHk0wPaG0opxbwDUwZTJ7yUhYORgD8U4fW0rpiC3Si5a8BV06IPf8vVZst4"
ENV = {
    "apiTokens": MOCK_TOKEN,
    "regionCode": "uae",
    "AzureWebJobsStorage": "fakeconnection",
    "workspaceId": "6a183caf-a148-4a43-845a-db6f4e645bfb",
    "workspaceKey": "m4qj7Y+sgW1hTi66m07/++fkGl38Dq46DwmDwOdx/vaWU86N5x8NicNmBeXXmgSbosTIfpL+AEuLigwQhidVPw==",
}
MOCK_CLP_ID = "8c840873-3145-4e5a-aede-021679ce23d8"
MOCK_WB_ID = "WB-2-20200214-0003"


class TestQueueTriggerWb(TestCase):
    wb_details = {}
    wb_history = {}
    pwd = os.path.dirname(__file__)

    def setUp(self):
        self.wb_details = open(f"{self.pwd}/data/wb_details.json")
        self.wb_details = json.load(self.wb_details)['data']

        self.wb_history = open(f"{self.pwd}/data/wb_history.json")
        self.wb_history = json.load(self.wb_history)['data']['workbenchRecords'][0]

        patcher = patch.dict('os.environ', ENV)
        patcher.start()
        self.addCleanup(patcher.stop)
        self.queue_trigger_wb = importlib.import_module('queue_trigger_wb')
        return super().setUp()

    def test_process_impact_scope_success(self):
        json_data = self.queue_trigger_wb.process_impact_scope(self.wb_details)

        self.assertEqual(json_data['UserAccountNTDomain'], ["shockwave", "testDomain"])
        self.assertEqual(
            json_data['UserAccountName'],
            ["testAccount1", "debbie", "testAccount2", "testAccount3"],
        )
        self.assertEqual(json_data['HostHostName'], ["test-1", "test-2"])

    def test_process_indicators_success(self):
        json_data = self.queue_trigger_wb.process_indicators(self.wb_details)

        self.assertEqual(
            json_data['ProcessCommandLine'],
            [
                "c:\\windows\\system32\\windowspowershell\\v1.0\\powershell.exe",
                "c:\\notepad.exe",
            ],
        )
        self.assertEqual(
            json_data['FileDirectory'],
            ["c:\\users\\debbie\\appdata\\local\\temp\\ds7002.pdf.lnk"],
        )
        self.assertEqual(json_data['FileName'], ["ds7002.pdf.lnk"])

    def test_customize_json_success(self):
        json_data = self.queue_trigger_wb.customize_json(
            MOCK_CLP_ID, self.wb_details, self.wb_history
        )

        self.assertEqual(json_data['priorityScore'], 60)
        self.assertEqual(json_data['workbenchId'], "WB-2-20200214-0003")
        self.assertEqual(json_data['alertProvider'], "SAE")

    @patch('queue_trigger_wb.utils.find_token_by_clp')
    @patch('queue_trigger_wb.get_workbench_detail')
    @patch('queue_trigger_wb.customize_json')
    @patch('queue_trigger_wb.LogAnalytics')
    @patch('queue_trigger_wb.get_rca_task')
    def test_main_success(
        self,
        mock_get_rca_task,
        mock_log_analytics,
        mock_customize_json,
        mock_get_workbench_detail,
        mock_find_token_by_clp,
    ):
        with open(f"{self.pwd}/data/prca_tasks.json") as f:
            rca_result = json.load(f)['data']

        wbMsg = MagicMock()
        rcaMsg = MagicMock()

        wbMsg.get_json.return_value = {
            "clp_id": MOCK_CLP_ID,
            "workbench_record": self.wb_history,
        }

        mock_find_token_by_clp.return_value = MOCK_TOKEN
        mock_customize_json.return_value = {}
        mock_get_rca_task.return_value = rca_result

        self.queue_trigger_wb.main(wbMsg, rcaMsg)

        mock_get_workbench_detail.assert_called_with(MOCK_TOKEN, "WB-2-20200214-0003")

        self.assertEqual(mock_log_analytics.call_count, 2)

        rcaMsg.set.assert_called_with(
            [
                self.queue_trigger_wb.build_queue_message(
                    MOCK_CLP_ID,
                    MOCK_WB_ID,
                    "3fa85f64-5717-4562-b3fc-2c963f66afa6",
                    "WB-1-20191025-00001-PTE_RCA-9b034206",
                    "35FA11DA-A24E-40CF-8B56-AAAAAAAAAAAA",
                    {
                        "host": "string",
                        "ip": ["string"],
                        "guid": "35FA11DA-A24E-40CF-8B56-AAAAAAAAAAAA",
                    },
                ),
                self.queue_trigger_wb.build_queue_message(
                    MOCK_CLP_ID,
                    MOCK_WB_ID,
                    "3fa85f64-5717-4562-b3fc-2c963f66afa6",
                    "WB-1-20191025-00001-PTE_RCA-9b034206",
                    "35FA11DA-A24E-40CF-8B56-DDDDDDDDDDDD",
                    {
                        "host": "string",
                        "ip": ["string"],
                        "guid": "35FA11DA-A24E-40CF-8B56-DDDDDDDDDDDD",
                    },
                ),
            ]
        )

    @patch('queue_trigger_wb.utils.find_token_by_clp')
    @patch('queue_trigger_wb.get_workbench_detail')
    @patch('queue_trigger_wb.customize_json')
    @patch('queue_trigger_wb.LogAnalytics')
    @patch('queue_trigger_wb.get_rca_task')
    def test_main_rca_result_not_process_complete_success(
        self,
        mock_get_rca_task,
        mock_log_analytics,
        mock_customize_json,
        mock_get_workbench_detail,
        mock_find_token_by_clp,
    ):

        rca_result = open(f"{self.pwd}/data/rca_results_not_process_complete.json")
        rca_result = json.load(rca_result)['data']

        wbMsg = MagicMock()
        rcaMsg = MagicMock()

        wbMsg.get_json.return_value = {
            "clp_id": MOCK_CLP_ID,
            "workbench_record": self.wb_history,
        }

        mock_find_token_by_clp.return_value = MOCK_TOKEN
        mock_customize_json.return_value = {}
        mock_get_rca_task.return_value = rca_result

        self.queue_trigger_wb.main(wbMsg, rcaMsg)

        mock_get_workbench_detail.assert_called_with(MOCK_TOKEN, "WB-2-20200214-0003")
        mock_log_analytics.assert_called_with(
            ANY, ANY, configurations.get_wb_log_type()
        )
        rcaMsg.set.assert_not_called()

    @patch('queue_trigger_wb.utils.find_token_by_clp')
    @patch('queue_trigger_wb.get_workbench_detail')
    @patch('queue_trigger_wb.customize_json')
    @patch('queue_trigger_wb.LogAnalytics')
    @patch('queue_trigger_wb.get_rca_task')
    def test_main_get_workbench_detail_failed_throw_exception(
        self,
        mock_get_rca_task,
        mock_log_analytics,
        mock_customize_json,
        mock_get_workbench_detail,
        mock_find_token_by_clp,
    ):

        wbMsg = MagicMock()
        rcaMsg = MagicMock()

        wbMsg.get_json.return_value = {
            "clp_id": MOCK_CLP_ID,
            "workbench_record": self.wb_history,
        }

        mock_find_token_by_clp.return_value = MOCK_TOKEN
        mock_get_workbench_detail.side_effect = HTTPError()

        with self.assertRaises(HTTPError):
            self.queue_trigger_wb.main(wbMsg, rcaMsg)

        mock_customize_json.assert_not_called()
        mock_get_rca_task.assert_not_called()
        mock_log_analytics.assert_not_called()
        rcaMsg.set.assert_not_called()

    @patch('queue_trigger_wb.utils.find_token_by_clp')
    @patch('queue_trigger_wb.get_workbench_detail')
    @patch('queue_trigger_wb.customize_json')
    @patch('queue_trigger_wb.LogAnalytics')
    @patch('queue_trigger_wb.get_rca_task')
    def test_main_unexpected_failed_throw_exception(
        self,
        mock_get_rca_task,
        mock_log_analytics,
        mock_customize_json,
        mock_get_workbench_detail,
        mock_find_token_by_clp,
    ):
        wbMsg = MagicMock()
        rcaMsg = MagicMock()

        wbMsg.get_json.return_value = {
            "clp_id": MOCK_CLP_ID,
            "workbench_record": self.wb_history,
        }

        mock_find_token_by_clp.return_value = MOCK_TOKEN
        mock_customize_json.side_effect = Exception()

        with self.assertRaises(Exception):
            self.queue_trigger_wb.main(wbMsg, rcaMsg)

        mock_get_workbench_detail.assert_called_with(MOCK_TOKEN, "WB-2-20200214-0003")
        mock_log_analytics.assert_not_called()
        mock_get_rca_task.assert_not_called()
        rcaMsg.set.assert_not_called()
