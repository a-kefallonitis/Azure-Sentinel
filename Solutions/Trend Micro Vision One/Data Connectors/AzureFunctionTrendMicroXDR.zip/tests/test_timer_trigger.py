import unittest
import importlib

from unittest.mock import ANY, patch, MagicMock
from datetime import datetime, timedelta

from requests.models import HTTPError


MOCK_TOKEN = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJjaWQiOiI4Yzg0MDg3My0zMTQ1LTRlNWEtYWVkZS0wMjE2NzljZTIzZDgiLCJjcGlkIjoic3ZwIiwicHBpZCI6ImN1cyIsIml0IjoxNjE1ODgwNzg1LCJ1aWQiOiJteGRyXzRiOTE0ZTYyQG1kci50cmVuZG1pY3JvLmNvbSIsInBsIjoiIiwiZXQiOjE2NDc0MTY3ODV9.V2SZHU85H8K55DpzHemToIr55kWaOQMWVV5CdImKGSePpntapsqW1tIEKbpuAemMyicKUNM1ewwC8fwJNZl7bW8puugYg92ynkXWGqKQiureKwCZM7Kfp-L-4LUvTsLF_DVDCECsptJNKkFZANryKqOFdEmiowmwRaqkoHkDT5qF_xCRnGx5nfzof8Nb_ey6PMQuH2mdOJRtfHkW4m9HZ3C-Ab2kuizD3J-BkOWGmn642hv1C9ClNp5IesMF_bhT21rIO4jkSW6GPz5nb9cEFMuepJK7F8177BGNh8LfJzfmeGgX141QGje4LdSXGq0eUlXzFxg0hMAXCS35a6bQeKGTh5Dfnxt4iSGLq47_ddiSEBifWuMiLyjAbxxV9QiF-Bee9q_gZdsczJCO9c7I4eoW2acqTOva-Ts0VVenXrp0g5qdBtZgoFOG4BZj_dnzla3fUa60rFlsE6_4VbSv0-mV7yZirRrB7cxwb2Gqzw_7dFCdKEg3Eax5ljT882FtJeUFGH1cOyUf-Uj4YlfByDSQyvPtqlyNoHX66Jz6yauWuJbL9n1cN_ZseKdf3gQtRRenNTLZG84dATj-WKYcp3w-KJtpCEDxLFbZFwb5Te7NlxrItHk0wPaG0opxbwDUwZTJ7yUhYORgD8U4fW0rpiC3Si5a8BV06IPf8vVZst4'
ENV = {
    "apiTokens": MOCK_TOKEN,
    "regionCode": "us",
    "AzureWebJobsStorage": "fakeconnection",
    "workspaceId": "6a183caf-a148-4a43-845a-db6f4e645bfb",
    "workspaceKey": "m4qj7Y+sgW1hTi66m07/++fkGl38Dq46DwmDwOdx/vaWU86N5x8NicNmBeXXmgSbosTIfpL+AEuLigwQhidVPw==",
    "defaultWorkbenchQueryMinutes": '5',
    "maxWorkbenchQueryMinutes": '60',
}
MOCK_CLP_ID = '8c840873-3145-4e5a-aede-021679ce23d8'


class TestTimerTrigger(unittest.TestCase):
    def setUp(self):
        patcher = patch.dict('os.environ', ENV)
        patcher.start()
        self.addCleanup(patcher.stop)
        self.timer_trigger = importlib.reload(importlib.import_module('timer_trigger'))
        super().setUp()

    @patch('timer_trigger.update_last_success_time')
    @patch('timer_trigger.generate_time')
    @patch('timer_trigger.get_workbench_list')
    @patch('timer_trigger.TableService')
    def test_timer_trigger_success(
        self, table_service, get_workbench_list, generate_time, update_last_success_time
    ):
        req = MagicMock()
        wbMsg = MagicMock()

        mock_workbench_record = {'workbenchId': 1}
        get_workbench_list.return_value = 1, [mock_workbench_record]
        mock_start_time = datetime(2021, 4, 1, 12, 0, 0)
        mock_end_time = datetime(2021, 4, 1, 12, 5, 0)
        generate_time.return_value = mock_start_time, mock_end_time

        self.timer_trigger.main(req, wbMsg)

        get_workbench_list.assert_called_with(MOCK_TOKEN, ANY, ANY)
        wbMsg.set.assert_called_with(
            [self.timer_trigger.build_queue_message(MOCK_CLP_ID, mock_workbench_record)]
        )
        update_last_success_time.assert_called_with(
            table_service(), MOCK_CLP_ID, mock_end_time
        )

    @patch('timer_trigger.update_last_success_time')
    @patch('timer_trigger.generate_time')
    @patch('timer_trigger.get_workbench_list')
    @patch('timer_trigger.TableService')
    def test_timer_trigger_when_have_more_pages_then_get_all_pages(
        self, table_service, get_workbench_list, generate_time, update_last_success_time
    ):
        req = MagicMock()
        wbMsg = MagicMock()

        mock_workbench_record = {'workbenchId': 1}
        get_workbench_list.side_effect = lambda x, y, z, a=0: (
            10,
            [mock_workbench_record, mock_workbench_record],
        )
        mock_start_time = datetime(2021, 4, 1, 12, 0, 0)
        mock_end_time = datetime(2021, 4, 1, 12, 5, 0)
        generate_time.return_value = mock_start_time, mock_end_time

        self.timer_trigger.main(req, wbMsg)

        self.assertEqual(get_workbench_list.call_count, 5)
        wbMsg.set.assert_called_with(
            [self.timer_trigger.build_queue_message(MOCK_CLP_ID, mock_workbench_record)]
            * 10
        )
        update_last_success_time.assert_called_with(
            table_service(), MOCK_CLP_ID, mock_end_time
        )

    @patch('timer_trigger.LogAnalytics')
    @patch('timer_trigger.update_last_success_time')
    @patch('timer_trigger.generate_time')
    @patch('timer_trigger.get_workbench_list')
    @patch('timer_trigger.TableService')
    def test_timer_trigger_error(
        self,
        table_service,
        get_workbench_list,
        generate_time,
        update_last_success_time,
        log_ananlytics,
    ):
        req = MagicMock()
        wbMsg = MagicMock()

        get_workbench_list.side_effect = HTTPError()
        mock_start_time = datetime(2021, 4, 1, 12, 0, 0)
        mock_end_time = datetime(2021, 4, 1, 12, 5, 0)
        generate_time.return_value = mock_start_time, mock_end_time

        with self.assertRaises(HTTPError):
            self.timer_trigger.main(req, wbMsg)

        get_workbench_list.assert_called_with(MOCK_TOKEN, ANY, ANY)
        wbMsg.set.assert_not_called()
        update_last_success_time.assert_not_called()
        log_ananlytics().post_data.assert_called_with(
            {
                "clpId": MOCK_CLP_ID,
                "queryStartTime": ANY,
                "queryEndTime": ANY,
                "error": str(HTTPError()),
            }
        )

    @patch('timer_trigger.datetime')
    @patch('timer_trigger.get_last_success_time')
    def test_generate_time_with_default_time(
        self, get_last_success_time, mock_datetime
    ):
        mock_start_time = datetime(2021, 4, 21, 8, 50)
        mock_end_time = datetime(2021, 4, 21, 8, 55)
        get_last_success_time.return_value = None
        mock_datetime.utcnow.return_value = mock_end_time

        result = self.timer_trigger.generate_time(None, MOCK_CLP_ID)

        self.assertTupleEqual(result, (mock_start_time, mock_end_time))

    @patch('timer_trigger.datetime')
    @patch('timer_trigger.get_last_success_time')
    def test_generate_time_with_last_success_time(
        self, get_last_success_time, mock_datetime
    ):
        mock_start_time = datetime(2021, 4, 21, 8, 55)
        mock_end_time = datetime(2021, 4, 21, 8, 55)
        get_last_success_time.return_value = mock_start_time
        mock_datetime.utcnow.return_value = mock_end_time

        result = self.timer_trigger.generate_time(None, MOCK_CLP_ID)

        self.assertTupleEqual(result, (mock_start_time, mock_end_time))

    @patch('timer_trigger.datetime')
    @patch('timer_trigger.get_last_success_time')
    def test_generate_time_with_last_success_time_over_max_time_range(
        self, get_last_success_time, mock_datetime
    ):
        mock_start_time = datetime(2021, 4, 20, 8, 55)
        mock_end_time = datetime(2021, 4, 21, 8, 55)
        get_last_success_time.return_value = mock_start_time
        mock_datetime.utcnow.return_value = mock_end_time

        result = self.timer_trigger.generate_time(None, MOCK_CLP_ID)

        self.assertTupleEqual(
            result, (mock_start_time, mock_start_time + timedelta(minutes=60))
        )
